"""Cache hit, invalidation, corruption and failure regression coverage."""
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from margyt.dexcache import DexCache


class CacheTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.jar = self.root / 'smali.jar'
        self.jar.write_bytes(b'tool-version-1')
        self.smali = SimpleNamespace(jar=str(self.jar), api=23)
        self.dex = b'dex\n035\0original'
        self.output = b'dex\n035\0patched'
        self.java = patch('margyt.dexcache.subprocess.run', return_value=
                          SimpleNamespace(stdout=b'', stderr=b'java17'))
        self.java.start()
        self.addCleanup(self.java.stop)
        self.cache = self.new_cache()

    def new_cache(self):
        return DexCache(self.root / 'cache', self.smali, lambda _: None)

    def run_patch(self, cache=None, literals=None, dex=None):
        return (cache or self.cache).patch(dex or self.dex, 'classes.dex', self.smali,
                                          str(self.root / 'work'), literals or {})

    def test_repeated_build_skips_native_patch_and_restores_counts(self):
        with patch('margyt.dexcache.dexpatch.patch', return_value=(self.output, {'calls': 2})) as native:
            self.assertEqual(self.run_patch(), (self.output, {'calls': 2}))
            self.assertEqual(self.run_patch(self.new_cache()), (self.output, {'calls': 2}))
            self.assertEqual(native.call_count, 1)

    def test_invalidation(self):
        with patch('margyt.dexcache.dexpatch.patch', return_value=(self.output, {'calls': 1})) as native:
            self.run_patch()
            self.run_patch(literals={'old': 'new'})
            self.run_patch(dex=b'dex\n035\0different')
            self.smali.api = 24
            self.run_patch(self.new_cache())
            self.jar.write_bytes(b'tool-version-2')
            self.run_patch(self.new_cache())
            changed = self.new_cache()
            changed.inputs['patcher'] = 'new-rule-code'
            self.run_patch(changed)
            self.assertEqual(native.call_count, 6)

    def test_corrupt_output_and_truncated_archive_rebuild(self):
        with patch('margyt.dexcache.dexpatch.patch', return_value=(self.output, {'calls': 1})) as native:
            self.run_patch()
            path = next((self.root / 'cache').glob('*.zip'))
            with zipfile.ZipFile(path) as z:
                meta = z.read('meta.json')
            with zipfile.ZipFile(path, 'w') as z:
                z.writestr('meta.json', meta)
                z.writestr('output.dex', b'dex\n035\0wrong')
            self.run_patch()
            path.write_bytes(b'partial zip')
            self.run_patch()
            self.assertEqual(native.call_count, 3)

    def test_failure_not_cached(self):
        with patch('margyt.dexcache.dexpatch.patch', side_effect=RuntimeError('assembly failed')):
            with self.assertRaises(RuntimeError):
                self.run_patch()
        self.assertFalse(list((self.root / 'cache').glob('*.zip')))

    def test_no_rewrites_are_cached_too(self):
        with patch('margyt.dexcache.dexpatch.patch', return_value=(self.dex, {})) as native:
            self.run_patch()
            self.assertEqual(self.run_patch(), (self.dex, {}))
            self.assertEqual(native.call_count, 1)

    def test_unwritable_cache_does_not_fail_build(self):
        self.cache.directory.write_bytes(b'not a directory')
        with patch('margyt.dexcache.dexpatch.patch', return_value=(self.output, {})):
            self.assertEqual(self.run_patch(), (self.output, {}))
