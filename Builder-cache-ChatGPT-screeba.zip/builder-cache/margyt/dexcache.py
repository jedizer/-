"""Content-addressed cache for the expensive, deterministic DEX patch stage.

Modified by ChatGPT & screeba, 2026-10-04. No APKs or signing keys are cached.
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
import tempfile
import time
import zipfile
from pathlib import Path

from . import dexpatch


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


class DexCache:
    def __init__(self, directory, smali, log=print):
        self.directory = Path(directory)
        self.log = log
        # Resolve once per build, not once per DEX. Include runtime identity:
        # changing Java/Python or the assembler must not reuse old output.
        java = subprocess.run(['java', '-version'], capture_output=True, check=True)
        self.inputs = {
            'schema': 1,
            'patcher': file_digest(dexpatch.__file__),
            'cache_impl': file_digest(__file__),
            'assembler': file_digest(smali.jar),
            'api': smali.api,
            'java': digest(java.stdout + java.stderr),
            'python': platform.python_version(),
        }

    def key(self, dex, name, literals):
        return digest(json.dumps(dict(self.inputs, dex=digest(dex), name=name,
                                      literals=literals or {}),
                                 sort_keys=True, separators=(',', ':')).encode())

    def load(self, key):
        try:
            with zipfile.ZipFile(self.directory / (key + '.zip')) as z:
                meta = json.loads(z.read('meta.json'))
                data = z.read('output.dex')
            counts = meta['counts']
            if (meta['key'] != key or meta['sha256'] != digest(data)
                    or not data.startswith(b'dex\n') or not isinstance(counts, dict)
                    or any(not isinstance(k, str) or type(v) is not int or v < 0
                           for k, v in counts.items())):
                raise ValueError('cache integrity check failed')
            return data, counts
        except FileNotFoundError:
            return None
        except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile, EOFError) as e:
            self.log('cache ignored: %s' % e)
            return None

    def store(self, key, data, counts):
        temp = None
        try:
            self.directory.mkdir(parents=True, exist_ok=True)
            fd, temp = tempfile.mkstemp(prefix='pending-', suffix='.zip', dir=self.directory)
            os.close(fd)
            with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_STORED) as z:
                z.writestr('output.dex', data)
                z.writestr('meta.json', json.dumps({
                    'key': key, 'sha256': digest(data), 'counts': counts}))
            # A single atomic publication avoids half-written DEX/metadata pairs.
            os.replace(temp, self.directory / (key + '.zip'))
        except OSError as e:
            self.log('cache write skipped: %s' % e)
        finally:
            if temp and os.path.exists(temp):
                os.unlink(temp)

    def patch(self, dex, name, smali, workspace, literals):
        started = time.monotonic()
        key = self.key(dex, name, literals)
        result = self.load(key)
        if result is not None and dexpatch.dex_format(result[0]) == dexpatch.dex_format(dex):
            self.log('%s: cache HIT (%.2fs)' % (name, time.monotonic() - started))
            return result
        # The existing patch function checks DEX format before returning.
        result = dexpatch.patch(dex, name, smali, workspace, literals)
        self.store(key, *result)
        self.log('%s: cache MISS, patched in %.2fs' % (name, time.monotonic() - started))
        return result
